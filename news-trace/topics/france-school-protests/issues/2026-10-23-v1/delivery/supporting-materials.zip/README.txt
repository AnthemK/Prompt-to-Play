codeX Special Report — France, 23 October 2026
All report material is in English; original source titles may be French.
report.md: complete report.
reading-guide.md: selected analytical reading.
evidence.md: source and claim register with review.
sources.json: machine-readable source metadata.
No full copyrighted articles are included. Direct article links may require subscriptions.
