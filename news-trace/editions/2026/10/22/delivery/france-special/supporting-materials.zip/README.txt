Supporting research for the France special report, 22 October 2026.
verification-notes.md: final verification and access record.
initial-research-dossier.md: earlier research, superseded where corrected by the final briefing.
The complete briefing is attached separately as full-briefing.md. No full copyrighted articles are included.
